$ErrorActionPreference = "SilentlyContinue"

$zapretDir = Join-Path $PSScriptRoot "fnz_net"
$launcher = Join-Path $zapretDir "general (ALT9).bat"

if (Test-Path -LiteralPath $launcher) {
    Start-Process -FilePath $env:ComSpec -ArgumentList @("/c", "call `"$launcher`"") -WorkingDirectory $zapretDir -WindowStyle Minimized
}
