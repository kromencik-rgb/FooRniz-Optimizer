@echo off
setlocal EnableExtensions

chcp 65001 >nul
title FooRniz optimizer BETA
cd /d "%~dp0"

set "LAUNCHER=%~f0"
set "SCRIPT=%~dp0modules\FooRnizOptimizer.ps1"

net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo.
    echo Requesting administrator rights...
    "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath $env:LAUNCHER -Verb RunAs"
    exit /b
)

if not exist "%SCRIPT%" (
    echo.
    echo [ERROR] Module not found:
    echo %SCRIPT%
    echo.
    pause
    exit /b 1
)

"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
set "EXITCODE=%errorlevel%"

if not "%EXITCODE%"=="0" (
    echo.
    echo Program finished with error: %EXITCODE%
    pause
)

endlocal
exit /b %EXITCODE%
