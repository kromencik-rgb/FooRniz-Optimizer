﻿$ErrorActionPreference = "Continue"

try {
    [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new()
    $OutputEncoding = [Console]::OutputEncoding
} catch {
}

$Script:Root = Split-Path -Parent $PSScriptRoot
$Script:DataDir = Join-Path $Script:Root "data"
$Script:LogDir = Join-Path $Script:Root "logs"
$Script:BackupDir = Join-Path $Script:DataDir "backups"
$Script:ZapretDir = Join-Path $Script:DataDir "fnz_net"
$Script:ZapretLauncher = Join-Path $Script:ZapretDir "general (ALT9).bat"
$Script:ZapretAutoStartScript = Join-Path $Script:DataDir "StartFooRnizZapret.ps1"
$Script:ZapretTaskName = "FooRniz Zapret Autostart"
$Script:LogFile = Join-Path $Script:LogDir ("optimizer_{0}.log" -f (Get-Date -Format "yyyy-MM-dd_HH-mm-ss"))

New-Item -ItemType Directory -Force -Path $Script:DataDir, $Script:LogDir, $Script:BackupDir | Out-Null

$Script:Config = @{
    name = "FooRniz optimizer"
    version = "BETA"
}

$configPath = Join-Path $Script:DataDir "config.json"
if (Test-Path -LiteralPath $configPath) {
    try {
        $Script:Config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
    } catch {
        $Script:Config = @{
            name = "FooRniz optimizer"
            version = "BETA"
        }
    }
}

function Write-Log {
    param(
        [Parameter(Mandatory = $true)][string]$Message,
        [string]$Level = "INFO"
    )

    $line = "[{0}] [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Level, $Message
    Add-Content -LiteralPath $Script:LogFile -Encoding UTF8 -Value $line
}

function Test-IsAdmin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Show-Header {
    param([string]$Title)

    Clear-Host
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor DarkCyan
    Write-Host (" {0} {1}" -f $Script:Config.name, $Script:Config.version) -ForegroundColor Cyan
    Write-Host (" {0}" -f $Title) -ForegroundColor White
    Write-Host "============================================================" -ForegroundColor DarkCyan
    Write-Host (" Лог: {0}" -f $Script:LogFile) -ForegroundColor DarkGray
    Write-Host ""
}

function Pause-Menu {
    Write-Host ""
    Read-Host "Нажми Enter, чтобы продолжить" | Out-Null
}

function Confirm-Action {
    param([Parameter(Mandatory = $true)][string]$Text)

    Write-Host ""
    Write-Host $Text -ForegroundColor Yellow
    $answer = Read-Host "Продолжить? (Y/N)"
    return ($answer -match "^(y|yes|д|да)$")
}

function Invoke-Step {
    param(
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][scriptblock]$Action
    )

    Write-Host ("[>] {0}" -f $Name) -ForegroundColor Gray
    Write-Log $Name
    try {
        & $Action
        Write-Host ("[OK] {0}" -f $Name) -ForegroundColor Green
        Write-Log "$Name - OK"
    } catch {
        Write-Host ("[!] {0}: {1}" -f $Name, $_.Exception.Message) -ForegroundColor Yellow
        Write-Log "$Name - $($_.Exception.Message)" "WARN"
    }
}

function Expand-SafePath {
    param([string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) {
        return $null
    }

    return [Environment]::ExpandEnvironmentVariables($Path)
}

function Clear-FolderContent {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [string]$Filter = "*"
    )

    $expanded = Expand-SafePath $Path
    if (-not $expanded -or -not (Test-Path -LiteralPath $expanded)) {
        return
    }

    Get-ChildItem -LiteralPath $expanded -Force -Filter $Filter -ErrorAction SilentlyContinue |
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
}

function Remove-FileIfExists {
    param([Parameter(Mandatory = $true)][string]$Path)

    $expanded = Expand-SafePath $Path
    if ($expanded -and (Test-Path -LiteralPath $expanded)) {
        Remove-Item -LiteralPath $expanded -Force -ErrorAction SilentlyContinue
    }
}

function Stop-ServiceSafe {
    param([string[]]$Name)

    foreach ($item in $Name) {
        $svc = Get-Service -Name $item -ErrorAction SilentlyContinue
        if ($svc -and $svc.Status -ne "Stopped") {
            Stop-Service -Name $item -Force -ErrorAction SilentlyContinue
        }
    }
}

function Start-ServiceSafe {
    param([string[]]$Name)

    foreach ($item in $Name) {
        $svc = Get-Service -Name $item -ErrorAction SilentlyContinue
        if ($svc -and $svc.Status -ne "Running") {
            Start-Service -Name $item -ErrorAction SilentlyContinue
        }
    }
}

function Clear-TempFiles {
    Invoke-Step "Очистка временных папок пользователя и Windows" {
        foreach ($path in $Script:Config.safeTempPaths) {
            Clear-FolderContent -Path $path
        }
    }
}

function Clear-BrowserCache {
    Invoke-Step "Очистка кэша Chrome, Edge и Firefox" {
        $chromeRoots = @(
            "$env:LOCALAPPDATA\Google\Chrome\User Data",
            "$env:LOCALAPPDATA\Microsoft\Edge\User Data"
        )

        foreach ($root in $chromeRoots) {
            if (Test-Path -LiteralPath $root) {
                Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                    Clear-FolderContent -Path (Join-Path $_.FullName "Cache")
                    Clear-FolderContent -Path (Join-Path $_.FullName "Code Cache")
                    Clear-FolderContent -Path (Join-Path $_.FullName "GPUCache")
                    Clear-FolderContent -Path (Join-Path $_.FullName "Service Worker\CacheStorage")
                }
            }
        }

        $firefoxRoot = "$env:APPDATA\Mozilla\Firefox\Profiles"
        if (Test-Path -LiteralPath $firefoxRoot) {
            Get-ChildItem -LiteralPath $firefoxRoot -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                Clear-FolderContent -Path (Join-Path $_.FullName "cache2\entries")
                Clear-FolderContent -Path (Join-Path $_.FullName "startupCache")
            }
        }
    }
}

function Clear-ThumbCache {
    Invoke-Step "Очистка кэша миниатюр и иконок" {
        Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 1
        Clear-FolderContent -Path "$env:LOCALAPPDATA\Microsoft\Windows\Explorer" -Filter "thumbcache_*.db"
        Clear-FolderContent -Path "$env:LOCALAPPDATA\Microsoft\Windows\Explorer" -Filter "iconcache_*.db"
        Start-Process explorer.exe
    }
}

function Clear-Recycle {
    Invoke-Step "Очистка корзины" {
        Clear-RecycleBin -Force -ErrorAction SilentlyContinue
    }
}

function Clear-DnsCache {
    Invoke-Step "Сброс DNS-кэша" {
        ipconfig /flushdns | Out-Null
    }
}

function Clear-CrashDumps {
    Invoke-Step "Удаление дампов памяти и отчетов об ошибках" {
        Remove-FileIfExists "C:\Windows\MEMORY.DMP"
        Clear-FolderContent -Path "C:\Windows\Minidump"
        Clear-FolderContent -Path "$env:LOCALAPPDATA\CrashDumps"
        Clear-FolderContent -Path "C:\ProgramData\Microsoft\Windows\WER\ReportArchive"
        Clear-FolderContent -Path "C:\ProgramData\Microsoft\Windows\WER\ReportQueue"
    }
}

function Clear-WindowsUpdateCache {
    Invoke-Step "Очистка кэша Центра обновления Windows" {
        Stop-ServiceSafe -Name @("wuauserv", "bits", "dosvc")
        Clear-FolderContent -Path "C:\Windows\SoftwareDistribution\Download"
        Clear-FolderContent -Path "C:\Windows\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Cache"
        Start-ServiceSafe -Name @("bits", "wuauserv", "dosvc")
    }
}

function Clear-StoreCache {
    Invoke-Step "Сброс кэша Microsoft Store" {
        Start-Process -FilePath "wsreset.exe" -WindowStyle Hidden -Wait -ErrorAction SilentlyContinue
    }
}

function Clear-FontCache {
    Invoke-Step "Очистка кэша шрифтов" {
        Stop-ServiceSafe -Name @("FontCache")
        Clear-FolderContent -Path "C:\Windows\ServiceProfiles\LocalService\AppData\Local\FontCache"
        Clear-FolderContent -Path "$env:LOCALAPPDATA\FontCache"
        Start-ServiceSafe -Name @("FontCache")
    }
}

function Clear-DirectXShaderCache {
    Invoke-Step "Очистка DirectX Shader Cache" {
        Clear-FolderContent -Path "$env:LOCALAPPDATA\D3DSCache"
        Clear-FolderContent -Path "$env:LOCALAPPDATA\NVIDIA\DXCache"
        Clear-FolderContent -Path "$env:LOCALAPPDATA\AMD\DxCache"
    }
}

function Clear-ExplorerHistory {
    Invoke-Step "Очистка истории Проводника и RunMRU" {
        Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU" -Recurse -Force -ErrorAction SilentlyContinue
        Clear-FolderContent -Path "$env:APPDATA\Microsoft\Windows\Recent"
        Clear-FolderContent -Path "$env:APPDATA\Microsoft\Windows\Recent\AutomaticDestinations"
        Clear-FolderContent -Path "$env:APPDATA\Microsoft\Windows\Recent\CustomDestinations"
    }
}

function Clear-EventLogs {
    Invoke-Step "Очистка журналов событий Windows" {
        wevtutil el | ForEach-Object {
            wevtutil cl $_ 2>$null
        }
    }
}

function Invoke-QuickClean {
    Show-Header "Быстрая очистка"
    if (-not (Confirm-Action "Будут очищены временные файлы, корзина, DNS, миниатюры и дампы. Личные файлы не трогаются.")) {
        return
    }

    Clear-TempFiles
    Clear-Recycle
    Clear-DnsCache
    Clear-CrashDumps
    Clear-DirectXShaderCache
    Clear-ThumbCache
    Pause-Menu
}

function Invoke-DeepClean {
    Show-Header "Глубокая очистка"
    if (-not (Confirm-Action "Закрой браузеры. Будут очищены кэши браузеров, Windows Update, Store, шрифтов, история Проводника и другие временные данные.")) {
        return
    }

    Clear-TempFiles
    Clear-BrowserCache
    Clear-WindowsUpdateCache
    Clear-StoreCache
    Clear-FontCache
    Clear-ExplorerHistory
    Clear-Recycle
    Clear-DnsCache
    Clear-CrashDumps
    Clear-DirectXShaderCache

    if (Confirm-Action "Очистить журналы событий Windows? Это может убрать данные для диагностики ошибок.") {
        Clear-EventLogs
    }

    Pause-Menu
}

function Optimize-Memory {
    Show-Header "Оптимизация ОЗУ"
    Write-Host "Функция не добавляет физическую память и не закрывает программы." -ForegroundColor Gray
    Write-Host "Она просит процессы отдать неиспользуемые страницы памяти Windows." -ForegroundColor Gray

    if (-not (Confirm-Action "Возможна краткая задержка у открытых программ после очистки рабочего набора.")) {
        return
    }

    Invoke-Step "Сборка мусора PowerShell/.NET" {
        [GC]::Collect()
        [GC]::WaitForPendingFinalizers()
        [GC]::Collect()
    }

    Invoke-Step "Обрезка рабочего набора процессов" {
        $signature = @"
using System;
using System.Runtime.InteropServices;

public static class Win32Memory {
    [DllImport("psapi.dll")]
    public static extern bool EmptyWorkingSet(IntPtr hProcess);
}
"@
        if (-not ("Win32Memory" -as [type])) {
            Add-Type -TypeDefinition $signature -ErrorAction SilentlyContinue
        }

        $skip = @("Idle", "System", "Registry", "Memory Compression")
        Get-Process -ErrorAction SilentlyContinue | Where-Object { $skip -notcontains $_.ProcessName } | ForEach-Object {
            try {
                [Win32Memory]::EmptyWorkingSet($_.Handle) | Out-Null
            } catch {
            }
        }
    }

    Pause-Menu
}

function Create-RestorePointSafe {
    Show-Header "Точка восстановления"
    if (-not (Confirm-Action "Windows попробует создать точку восстановления перед твиками.")) {
        return
    }

    Invoke-Step "Создание точки восстановления" {
        Enable-ComputerRestore -Drive "$env:SystemDrive\" -ErrorAction SilentlyContinue
        Checkpoint-Computer -Description "FooRniz optimizer restore point" -RestorePointType "MODIFY_SETTINGS" -ErrorAction Stop
    }
    Pause-Menu
}

function Start-Zapret {
    Show-Header "Запуск Zapret"
    Write-Host "BETA версия имеет встроенный запуск Zapret для обхода ограничений Roblox, YouTube, Discord и многого другого." -ForegroundColor Cyan
    Write-Host ""

    if (-not (Test-Path -LiteralPath $Script:ZapretLauncher)) {
        Write-Host "[!] Не найден файл запуска:" -ForegroundColor Yellow
        Write-Host $Script:ZapretLauncher -ForegroundColor Gray
        Write-Log "Zapret launcher not found: $Script:ZapretLauncher" "WARN"
        Pause-Menu
        return
    }

    if (-not (Confirm-Action "Будет запущен встроенный модуль Zapret: general (ALT9).bat")) {
        return
    }

    Invoke-Step "Запуск Zapret general (ALT9)" {
        Start-Process -FilePath $env:ComSpec -ArgumentList @("/c", "call `"$Script:ZapretLauncher`"") -WorkingDirectory $Script:ZapretDir -WindowStyle Minimized
    }

    Write-Host ""
    Write-Host "Zapret запущен. Лишнее окно cmd теперь должно закрываться автоматически." -ForegroundColor Green
    Write-Host "Окно FooRniz optimizer можно закрыть после включения Zapret." -ForegroundColor Green
    Pause-Menu
}

function Get-ZapretAutostartTask {
    return Get-ScheduledTask -TaskName $Script:ZapretTaskName -ErrorAction SilentlyContinue
}

function Show-ZapretAutostartStatus {
    $task = Get-ZapretAutostartTask
    if ($task) {
        Write-Host ("Статус автозапуска: {0}" -f $task.State) -ForegroundColor Green
    } else {
        Write-Host "Статус автозапуска: выключен" -ForegroundColor Yellow
    }
}

function Enable-ZapretAutostart {
    if (-not (Test-Path -LiteralPath $Script:ZapretAutoStartScript)) {
        Write-Host "[!] Не найден скрипт автозапуска:" -ForegroundColor Yellow
        Write-Host $Script:ZapretAutoStartScript -ForegroundColor Gray
        Write-Log "Zapret autostart script not found: $Script:ZapretAutoStartScript" "WARN"
        return
    }

    if (-not (Test-Path -LiteralPath $Script:ZapretLauncher)) {
        Write-Host "[!] Не найден файл запуска Zapret:" -ForegroundColor Yellow
        Write-Host $Script:ZapretLauncher -ForegroundColor Gray
        Write-Log "Zapret launcher not found: $Script:ZapretLauncher" "WARN"
        return
    }

    Invoke-Step "Включение автозапуска Zapret через Планировщик задач" {
        $powerShellPath = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"
        $argument = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$Script:ZapretAutoStartScript`""
        $action = New-ScheduledTaskAction -Execute $powerShellPath -Argument $argument
        $trigger = New-ScheduledTaskTrigger -AtLogOn
        $principal = New-ScheduledTaskPrincipal -UserId ([Security.Principal.WindowsIdentity]::GetCurrent().Name) -LogonType Interactive -RunLevel Highest
        $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 0)
        Register-ScheduledTask -TaskName $Script:ZapretTaskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description "Starts FooRniz built-in Zapret on user logon." -Force | Out-Null
    }
}

function Disable-ZapretAutostart {
    Invoke-Step "Выключение автозапуска Zapret" {
        $task = Get-ZapretAutostartTask
        if ($task) {
            Unregister-ScheduledTask -TaskName $Script:ZapretTaskName -Confirm:$false
        }
    }
}

function Manage-ZapretAutostart {
    while ($true) {
        Show-Header "Автозапуск Zapret"
        Write-Host "Если включить автозапуск, Zapret будет стартовать при входе в Windows." -ForegroundColor Cyan
        Write-Host "Окно FooRniz optimizer для этого открывать не нужно." -ForegroundColor Cyan
        Write-Host ""
        Show-ZapretAutostartStatus
        Write-Host ""
        Write-Host "[1] Включить автозапуск Zapret"
        Write-Host "[2] Выключить автозапуск Zapret"
        Write-Host "[3] Запустить Zapret сейчас"
        Write-Host "[B] Назад"
        Write-Host ""

        $choice = Read-Host "Выбор"
        switch -Regex ($choice) {
            "^1$" {
                if (Confirm-Action "Создать задачу Планировщика Windows для автозапуска Zapret?") {
                    Enable-ZapretAutostart
                }
                Pause-Menu
            }
            "^2$" {
                if (Confirm-Action "Удалить задачу автозапуска Zapret?") {
                    Disable-ZapretAutostart
                }
                Pause-Menu
            }
            "^3$" { Start-Zapret }
            "^(b|B|и|И)$" { return }
        }
    }
}

function Enable-GameModeTweaks {
    Invoke-Step "Включение игровых настроек Windows" {
        New-Item -Path "HKCU:\Software\Microsoft\GameBar" -Force | Out-Null
        New-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name "AllowAutoGameMode" -PropertyType DWord -Value 1 -Force | Out-Null
        New-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name "AutoGameModeEnabled" -PropertyType DWord -Value 1 -Force | Out-Null
        New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Force | Out-Null
        New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name "AppCaptureEnabled" -PropertyType DWord -Value 0 -Force | Out-Null
        New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR" -Force | Out-Null
        New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR" -Name "AllowGameDVR" -PropertyType DWord -Value 0 -Force | Out-Null
    }
}

function Set-PerformancePowerPlan {
    Invoke-Step "Включение плана питания Высокая производительность" {
        powercfg -setactive SCHEME_MIN | Out-Null
    }
}

function Disable-VisualEffects {
    Invoke-Step "Отключение части анимаций и прозрачности интерфейса" {
        New-Item -Path "HKCU:\Control Panel\Desktop\WindowMetrics" -Force | Out-Null
        New-ItemProperty -Path "HKCU:\Control Panel\Desktop\WindowMetrics" -Name "MinAnimate" -PropertyType String -Value "0" -Force | Out-Null
        New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" -Force | Out-Null
        New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" -Name "VisualFXSetting" -PropertyType DWord -Value 2 -Force | Out-Null
        New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" -Force | Out-Null
        New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" -Name "EnableTransparency" -PropertyType DWord -Value 0 -Force | Out-Null
    }
}

function Enable-UsefulExplorerSettings {
    Invoke-Step "Включение полезных настроек Проводника" {
        New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Force | Out-Null
        New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "ShowSecondsInSystemClock" -PropertyType DWord -Value 1 -Force | Out-Null
        New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "HideFileExt" -PropertyType DWord -Value 0 -Force | Out-Null
    }
}

function Disable-AdsAndSuggestions {
    Invoke-Step "Отключение части подсказок и рекламных предложений Windows" {
        New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Force | Out-Null
        $values = @(
            "ContentDeliveryAllowed",
            "OemPreInstalledAppsEnabled",
            "PreInstalledAppsEnabled",
            "SilentInstalledAppsEnabled",
            "SubscribedContent-338387Enabled",
            "SubscribedContent-338388Enabled",
            "SubscribedContent-353694Enabled",
            "SubscribedContent-353696Enabled",
            "SystemPaneSuggestionsEnabled"
        )

        foreach ($value in $values) {
            New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name $value -PropertyType DWord -Value 0 -Force | Out-Null
        }
    }
}

function Invoke-WindowsOptimization {
    while ($true) {
        Show-Header "Оптимизация Windows"
        Write-Host "[1] Создать точку восстановления"
        Write-Host "[2] Включить план питания Высокая производительность"
        Write-Host "[3] Игровой режим + отключить Game DVR запись"
        Write-Host "[4] Отключить анимации и прозрачность"
        Write-Host "[5] Отключить подсказки и рекламные предложения"
        Write-Host "[6] Показ расширений файлов и секунд на часах"
        Write-Host "[7] Применить рекомендуемый набор"
        Write-Host "[B] Назад"
        Write-Host ""
        $choice = Read-Host "Выбор"

        switch -Regex ($choice) {
            "^1$" { Create-RestorePointSafe }
            "^2$" { Set-PerformancePowerPlan; Pause-Menu }
            "^3$" { Enable-GameModeTweaks; Pause-Menu }
            "^4$" { Disable-VisualEffects; Pause-Menu }
            "^5$" { Disable-AdsAndSuggestions; Pause-Menu }
            "^6$" { Enable-UsefulExplorerSettings; Pause-Menu }
            "^7$" {
                if (Confirm-Action "Будут применены умеренные твики производительности. Рекомендуется заранее создать точку восстановления.") {
                    Set-PerformancePowerPlan
                    Enable-GameModeTweaks
                    Disable-VisualEffects
                    Disable-AdsAndSuggestions
                    Enable-UsefulExplorerSettings
                }
                Pause-Menu
            }
            "^(b|B|и|И)$" { return }
        }
    }
}

function Invoke-DiskTools {
    while ($true) {
        Show-Header "Диски и TRIM"
        Write-Host "[1] Анализ диска C:"
        Write-Host "[2] TRIM/оптимизация SSD для всех фиксированных дисков"
        Write-Host "[3] Открыть Очистку диска Windows"
        Write-Host "[4] Показать свободное место"
        Write-Host "[B] Назад"
        Write-Host ""
        $choice = Read-Host "Выбор"

        switch -Regex ($choice) {
            "^1$" {
                Invoke-Step "Анализ C:" { defrag C: /A /U /V }
                Pause-Menu
            }
            "^2$" {
                if (Confirm-Action "Windows сама выберет корректный режим: TRIM для SSD, оптимизация для HDD.") {
                    Invoke-Step "Оптимизация всех фиксированных дисков" {
                        Get-Volume | Where-Object { $_.DriveLetter -and $_.DriveType -eq "Fixed" } | ForEach-Object {
                            Optimize-Volume -DriveLetter $_.DriveLetter -Verbose
                        }
                    }
                }
                Pause-Menu
            }
            "^3$" {
                Invoke-Step "Запуск cleanmgr" { Start-Process cleanmgr.exe }
                Pause-Menu
            }
            "^4$" {
                Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" |
                    Select-Object DeviceID,
                        @{Name="СвободноГБ"; Expression={[math]::Round($_.FreeSpace / 1GB, 2)}},
                        @{Name="ВсегоГБ"; Expression={[math]::Round($_.Size / 1GB, 2)}} |
                    Format-Table -AutoSize
                Pause-Menu
            }
            "^(b|B|и|И)$" { return }
        }
    }
}

function Invoke-SystemRepair {
    while ($true) {
        Show-Header "Проверка и восстановление"
        Write-Host "[1] SFC /scannow"
        Write-Host "[2] DISM CheckHealth"
        Write-Host "[3] DISM RestoreHealth"
        Write-Host "[4] Запланировать CHKDSK C: при перезагрузке"
        Write-Host "[5] Сброс сетевого стека Winsock"
        Write-Host "[B] Назад"
        Write-Host ""
        $choice = Read-Host "Выбор"

        switch -Regex ($choice) {
            "^1$" {
                Invoke-Step "SFC /scannow" { sfc /scannow }
                Pause-Menu
            }
            "^2$" {
                Invoke-Step "DISM CheckHealth" { DISM /Online /Cleanup-Image /CheckHealth }
                Pause-Menu
            }
            "^3$" {
                Invoke-Step "DISM RestoreHealth" { DISM /Online /Cleanup-Image /RestoreHealth }
                Pause-Menu
            }
            "^4$" {
                if (Confirm-Action "Проверка диска может занять много времени после перезагрузки.") {
                    Invoke-Step "Планирование CHKDSK" { cmd /c "echo Y|chkdsk C: /f" }
                }
                Pause-Menu
            }
            "^5$" {
                if (Confirm-Action "После сброса сети желательно перезагрузить ПК.") {
                    Invoke-Step "Сброс Winsock" {
                        netsh winsock reset
                        netsh int ip reset
                        ipconfig /flushdns
                    }
                }
                Pause-Menu
            }
            "^(b|B|и|И)$" { return }
        }
    }
}

function Invoke-Tools {
    while ($true) {
        Show-Header "Инструменты"
        Write-Host "[1] Автозагрузка приложений"
        Write-Host "[2] Программы и компоненты"
        Write-Host "[3] Службы Windows"
        Write-Host "[4] Диспетчер задач"
        Write-Host "[5] Информация о системе"
        Write-Host "[6] Открыть папку логов"
        Write-Host "[7] Открыть папку встроенного Zapret"
        Write-Host "[B] Назад"
        Write-Host ""
        $choice = Read-Host "Выбор"

        switch -Regex ($choice) {
            "^1$" { Start-Process "ms-settings:startupapps" }
            "^2$" { Start-Process appwiz.cpl }
            "^3$" { Start-Process services.msc }
            "^4$" { Start-Process taskmgr.exe }
            "^5$" {
                Get-CimInstance Win32_OperatingSystem |
                    Select-Object Caption, Version, OSArchitecture,
                        @{Name="ПамятьГБ"; Expression={[math]::Round($_.TotalVisibleMemorySize / 1MB, 2)}} |
                    Format-List
                Get-CimInstance Win32_Processor | Select-Object Name, NumberOfCores, NumberOfLogicalProcessors | Format-List
                Pause-Menu
            }
            "^6$" { Start-Process explorer.exe $Script:LogDir }
            "^7$" { Start-Process explorer.exe $Script:ZapretDir }
            "^(b|B|и|И)$" { return }
        }
    }
}

function Show-MainMenu {
    while ($true) {
        Show-Header "Главное меню"
        if (-not (Test-IsAdmin)) {
            Write-Host "[!] Программа запущена без прав администратора. Часть функций не сработает." -ForegroundColor Yellow
            Write-Host ""
        }

        Write-Host "BETA: встроен Zapret для обхода Roblox, YouTube, Discord и многого другого." -ForegroundColor Cyan
        Write-Host ""
        Write-Host "[1] Быстрая очистка"
        Write-Host "[2] Глубокая очистка"
        Write-Host "[3] Оптимизация ОЗУ"
        Write-Host "[4] Оптимизация Windows и игр"
        Write-Host "[5] Диски, TRIM и свободное место"
        Write-Host "[6] Проверка и восстановление системы"
        Write-Host "[7] Запустить Zapret"
        Write-Host "[8] Автозапуск Zapret"
        Write-Host "[9] Инструменты Windows"
        Write-Host "[10] Создать точку восстановления"
        Write-Host "[0] Выход"
        Write-Host ""

        $choice = Read-Host "Выбор"
        switch -Regex ($choice) {
            "^1$" { Invoke-QuickClean }
            "^2$" { Invoke-DeepClean }
            "^3$" { Optimize-Memory }
            "^4$" { Invoke-WindowsOptimization }
            "^5$" { Invoke-DiskTools }
            "^6$" { Invoke-SystemRepair }
            "^7$" { Start-Zapret }
            "^8$" { Manage-ZapretAutostart }
            "^9$" { Invoke-Tools }
            "^10$" { Create-RestorePointSafe }
            "^0$" { return }
        }
    }
}

Write-Log "Program started"
Show-MainMenu
Write-Log "Program closed"
